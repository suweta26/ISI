from itertools import islice
import os
from os import listdir
from os.path import isfile, join
import re
import shutil


#path = '/home/neha/Desktop/ISI_final/test'
relationPath = '../../Data/Relations'
article_path='../../../2_Event_Filtering/Data/LDA_Filtered_Articles'
taggedArticlePath='../../Data/Tagged_Protest_Articles'
extracted_info_path = '../../Data/Extracted_information'
evaluationPath='../../Evaluation/heuristicTagged'
window_size=7


# Create the output folder if not exists
if os.path.isdir(extracted_info_path):
   shutil.rmtree(extracted_info_path)
os.makedirs(extracted_info_path)


if os.path.isdir(evaluationPath):
   shutil.rmtree(evaluationPath)
os.makedirs(evaluationPath)

#get the published date and title of each article
articleList=[]
titleDict={}
published_date={}
for article in os.listdir(article_path):
  articleList.append(article)

for article in articleList:
  with open(os.path.join(article_path,article), 'rU') as fp:
    for i, line in enumerate(fp):
      if i == 2:
        published_date[article]=line[:len(line)-2]
      if i == 1:
        titleDict[article]=line
  fp.close()

#extracts the realation ID from the relation
def getRelID(relation):
  relID=relation.split('(')
  relID=int(relID[0])
  return relID


#    "Returns a sliding window (of width n) over data from the iterable"
#    "   s -> (s0,s1,...s[n-1]), (s1,s2,...,sn), ...                   "
def window(seq, n):

    it = iter(seq)
    result = tuple(islice(it, n))
    if len(result) == n:
        yield result    
    for elem in it:
        result = result[1:] + (elem,)
        yield result


#main starts here
if __name__=="__main__":

#get the filelist of the directory at "relationPath"
  fileList=[]
  for filename in os.listdir(relationPath):
    fileList.append(filename)

  keywordList=['protest','protesting','protested','demonstartion','agitation','dharna','bandh','rally','rallies','gherao','activist','march towards','on strike']

  tagList=['/PERSON','/LOCATION','/DATE','/ORGANIZTION','/person','/location','/date','/organization']


#iterate over all the files
  for filename in fileList:
    print filename
    print titleDict[filename]

#read the relation file
    with open(os.path.join(relationPath,filename), 'rU') as f:
      dictPerson={}
      dictLocation={}
      dictOrganization={}
      dictDate={}
      relevanceDict={}

#parse the title
      with open(os.path.join(taggedArticlePath,filename), 'rU') as fp:
        i=0
        for i, line in enumerate(fp):
          if i==2:
            wordList=line.split(' ')
            k=-1
            for item in wordList:
              k=k+1
              if (k<len(wordList)) and ('/LOCATION' in wordList[k] or '/location' in wordList[k]):
                if (k+1<len(wordList)) and ('/LOCATION' in wordList[k+1] or '/location' in wordList[k+1]):
                  first=wordList[k]
                  first=first[:-9]
                  second=wordList[k+1]
                  second=second[:-9]
                  location=first+" "+second
                  k=k+1
                else:
                  location=wordList[k]
                  location=location[:-9]
                if location not in dictLocation:
                  dictLocation[location.lower()]=1

              if (k<len(wordList)) and ('/PERSON' in wordList[k] or '/person' in wordList[k]):
                if (k+1<len(wordList)) and ('/person' in wordList[k+1] or '/person' in wordList[k+1]):
                  if (k+2<len(wordList)) and ('/person' in wordList[k+2] or '/person' in wordList[k+2]):
                    first=wordList[k]
                    first=first[:-7]
                    second=wordList[k+1]
                    second=second[:-7]
                    third=wordList[k+2]
                    third=third[:-7]
                    person=first+" "+second+" "+third
                    k=k+2
                  else:
                    first=wordList[k]
                    first=first[:-7]
                    second=wordList[k+1]
                    second=second[:-7]
                    person=first+" "+second
                    k=k+1

                else:
                  person=wordList[k]
                  person=person[:-7]
                if person not in dictPerson:
                  dictPerson[person.lower()]=1


              if (k<len(wordList)) and ('/DATE' in wordList[k] or '/date' in wordList[k]):
                if (k+1<len(wordList)) and ('/DATE' in wordList[k+1] or '/date' in wordList[k+1]):
                  first=wordList[k]
                  first=first[:-5]
                  second=wordList[k+1]
                  second=second[:-5]
                  date=first+" "+second
                  k=k+1
                else:
                  date=wordList[k]
                  date=date[:-5]
                if date not in dictDate:
                  dictDate[date.lower()]=1

              if (k<len(wordList)) and ('/ORGANIZATION' in wordList[k] or '/oraganization' in wordList[k]):
                if (k+1<len(wordList)) and ('/ORGANIZATION' in wordList[k+1] or '/organization' in wordList[k+1]):
                  first=wordList[k]
                  first=first[:-13]
                  second=wordList[k+1]
                  second=second[:-13]
                  organization=first+" "+second
                  k=k+1
                else:
                  organization=wordList[k]
                  organization=organization[:-13]
                if organization not in dictOrganization:
                  dictOrganization[organization.lower()]=1
      fp.close()
#parsing title ends here

      #read relation file into content
      content = f.readlines()
      f.close()
      #to remove whitespace characters like `\n` at the end of each line
      content = [x.strip() for x in content] 

#iterarte over window
      for w in window(content,window_size):
        stringWindow=str(w)
        if any(keyword in stringWindow for keyword in keywordList):

#iterate over all the relation of the window
        
          for relation in w:
            person=""
            location=""
            date=""
            purpose=""
            organization=""
            flag=-1
            relevanceFlag=0			#default value of relation flag for each relation
            stringRel=str(relation)
            relID=getRelID(stringRel)		#get the realtion ID
            stringRel=stringRel[:-1]		#drop newline ("\n") at the end of the relation tuple
            stringRel=re.sub(r'.*\(', '', stringRel)   #drop the relID of the relation tuple

            if any(tag in stringRel for tag in tagList):
              #set relevance flag of this relation
              if any(keyword in stringRel for keyword in keywordList):
                relevanceFlag=1

              words=stringRel.split('#')			#remove "#" from the relation
              string=words[0]+" "+words[1]+" "+words[2]   
              wordList=string.split(' ')                  #wordList contains all the wsords of the relation tuple
            
              k=-1					#variable k to handles 'out of index' access to wordList
              for item in wordList:
                #extract info based on the tag associated with the word
                k=k+1

                #extract Location
                if (k<len(wordList)) and ('/LOCATION' in wordList[k] or '/location' in wordList[k]):
                  if (k+1<len(wordList)) and ('/LOCATION' in wordList[k+1] or '/location' in wordList[k+1]):
                    first=wordList[k]
                    first=first[:-9]
                    second=wordList[k+1]
                    second=second[:-9]
                    location=first+" "+second
                    k=k+1
                  else:
                    location=wordList[k]
                    location=location[:-9]
                  if location not in dictLocation:
                    dictLocation[location.lower()]=1

              #extract Person
                if (k<len(wordList)) and ('/PERSON' in wordList[k] or '/person' in wordList[k]):
                  if (k+1<len(wordList)) and ('/person' in wordList[k+1] or '/person' in wordList[k+1]):
                    if (k+2<len(wordList)) and ('/person' in wordList[k+2] or '/person' in wordList[k+2]):
                      first=wordList[k]
                      first=first[:-7]
                      second=wordList[k+1]
                      second=second[:-7]
                      third=wordList[k+2]
                      third=third[:-7]
                      person=first+" "+second+" "+third
                      k=k+2
                    else:
                      first=wordList[k]
                      first=first[:-7]
                      second=wordList[k+1]
                      second=second[:-7]
                      person=first+" "+second
                      k=k+1

                  else:
                    person=wordList[k]
                    person=person[:-7]
                  if person not in dictPerson:
                    dictPerson[person.lower()]=1

                #extract date
                if (k<len(wordList)) and ('/DATE' in wordList[k] or '/date' in wordList[k]):
                  if (k+1<len(wordList)) and ('/DATE' in wordList[k+1] or '/date' in wordList[k+1]):
                    first=wordList[k]
                    first=first[:-5]
                    second=wordList[k+1]
                    second=second[:-5]
                    date=first+" "+second
                    k=k+1
                  else:
                    date=wordList[k]
                    date=date[:-5]
                  if date not in dictDate:
                    dictDate[date.lower()]=1

                #extract organization
                if (k<len(wordList)) and ('/ORGANIZATION' in wordList[k] or '/oraganization' in wordList[k]):
                  if (k+1<len(wordList)) and ('/ORGANIZATION' in wordList[k+1] or '/organization' in wordList[k+1]):
                    first=wordList[k]
                    first=first[:-13]
                    second=wordList[k+1]
                    second=second[:-13]
                    organization=first+" "+second
                    k=k+1
                  else:
                    organization=wordList[k]
                    organization=organization[:-13]
                  if organization not in dictOrganization:
                    dictOrganization[organization.lower()]=1
        #write relevance flag for relation into dictionary
            relevanceDict[relID]=relevanceFlag
    for i in xrange(len(content)):
      if i+1 not in relevanceDict:
        relevanceDict[i+1]=0

#write the heuristic picked relation into file
    with open(os.path.join(evaluationPath,filename), 'w') as fileP:
      items = sorted(relevanceDict.items())
      for item in items:
          fileP.write(str(item[0])+"," + str(item[1])+"\n")

#write the extracted info into file
    completeName = os.path.join(extracted_info_path, filename)
    file1 = open(completeName, "w")

#write published date and title
    file1.write(published_date[filename])
    file1.write('\n'+titleDict[filename])

#write person
    if any(dictPerson):
      firstWordFlag=0
      for word,freq in dictPerson.items():
        if firstWordFlag < 5:
          firstWordFlag=firstWordFlag+1
          if firstWordFlag == 1:
            file1.write(word)
          else:
            file1.write(', '+word)
    else:
      file1.write('\nNone')                    # '\n' not required as title string end with \n

#write date
    if any(dictDate):
      file1.write('\n')
      firstWordFlag=1
      for word,freq in dictDate.items():
        if firstWordFlag == 1:
          file1.write(word)
          firstWordFlag=0
        else:
          file1.write(', '+word)
    else:
      file1.write('\n'+published_date[filename])

#write organization
    if any(dictOrganization):
      file1.write('\n')
      firstWordFlag=0
      for word,freq in dictOrganization.items():
        if firstWordFlag < 5:
          firstWordFlag=firstWordFlag+1
          if firstWordFlag == 1:
            file1.write(word)
          else:
            file1.write(', '+word)
    else:
      file1.write('\nNone')
#write location
    if any(dictLocation):
      file1.write('\n')
      firstWordFlag=0
      for word,freq in dictLocation.items():
        if firstWordFlag < 5:
          firstWordFlag=firstWordFlag+1
          if firstWordFlag == 1:
            file1.write(word)
          else:
            file1.write(', '+word)
    else:
      file1.write('\nNone')
