import os
from os import listdir
from os.path import isfile, join
from itertools import izip

heuristicTaggedPath='../../Evaluation/heuristicTagged'
manuallyTaggedPath='../../Evaluation/manuallyTagged'

manuallyTaggedFileList=[]
for filename in os.listdir(manuallyTaggedPath):
  manuallyTaggedFileList.append(filename)

taggedCount=0
pickedCount=0
truePositive=0
falsePositive=0
trueNegative=0
falseNegative=0

for filename in manuallyTaggedFileList:
  with open(os.path.join(heuristicTaggedPath,filename), 'rU') as file1, open(os.path.join(manuallyTaggedPath,filename), 'rU') as file2:
    for x, y in izip(file1,file2):
      relID,picked = x.split(',')
      relIDtagged,tagged = y.split(',')
      if int(tagged)==1:
        taggedCount=taggedCount+1
      if int(picked) == 1:
        pickedCount=pickedCount+1
      if int(picked) == 1 and int(tagged) == 0:
        falsePositive=falsePositive+1
      if int(picked) == 1 and int(tagged) == 1:
        truePositive=truePositive+1
      if int(picked) == 0 and int(tagged) == 1:
        falseNegative=falseNegative+1
      if int(picked) == 0 and int(tagged) == 0:
        trueNegative=trueNegative+1

print 'precision : %d/%d'%(truePositive,truePositive+falsePositive)
print 'recall : %d/%d'%(truePositive,truePositive+falseNegative)
print 'accuracy : %d/%d'%(truePositive+trueNegative,(truePositive+trueNegative+falsePositive+falseNegative))
