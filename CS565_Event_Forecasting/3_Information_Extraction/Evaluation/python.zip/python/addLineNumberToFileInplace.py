#!/usr/bin/python

import fileinput
import sys
import os

path = '../../Data/Relations'

fileList=[]

for filename in os.listdir(path):
  fileList.append(filename)

for filename in fileList:
  print filename
  with open(os.path.join(path,filename), 'r') as f:
    data = f.readlines()
  f.close()

  with open(os.path.join(path,filename), 'w') as f:
    for (number, line) in enumerate(data):
      print 'processing:'+filename
      f.write('%d%s' % (number + 1, line))
  f.close()
